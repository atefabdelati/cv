package com.suppor.kidssongs;

import android.Manifest;
import android.content.Context;
import android.support.annotation.RequiresPermission;
import android.widget.Toast;

import com.google.ads.consent.ConsentForm;
import com.google.ads.consent.ConsentFormListener;
import com.google.ads.consent.ConsentInfoUpdateListener;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;
import com.google.ads.consent.DebugGeography;

import java.net.URL;


public class PrivacyGDPRa {

    private ConsentInformation consentInformation;
    private Context context;
    private String privacyUrl;
    private ConsentForm consentForm;
    private String[] publisherIds;
    private static PrivacyGDPRa privacyGdprStance;

    protected PrivacyGDPRa(Context context) {
        this.context = context;
        this.consentInformation = ConsentInformation.getInstance(context);
    }

    public PrivacyGDPRa() {
    }

    public PrivacyGDPRa withContext(Context context) {
        privacyGdprStance = new PrivacyGDPRa(context);
        return privacyGdprStance;
    }

    public PrivacyGDPRa withPrivacyUrl(String privacyUrl) {
        this.privacyUrl = privacyUrl;
        if (privacyGdprStance == null)
            throw new NullPointerException("withContext");
        return privacyGdprStance;
    }

    @RequiresPermission(Manifest.permission.INTERNET)
    private void initGDPR() {


        if (publisherIds == null)
            throw new NullPointerException("publisherIds");
        consentInformation.requestConsentInfoUpdate(publisherIds, new ConsentInfoUpdateListener() {
            @Override
            public void onConsentInfoUpdated(ConsentStatus consentStatus) {
                if (consentStatus == ConsentStatus.UNKNOWN)
                    if (consentInformation.isRequestLocationInEeaOrUnknown())
                        setupForm();
                    else consentInformation.setConsentStatus(consentStatus);
                else
                    consentInformation.setConsentStatus(consentStatus);


            }

            @Override
            public void onFailedToUpdateConsentInfo(String errorDescription) {


            }
        });


    }

    private void setupForm() {
        if (privacyUrl == "") throw new NullPointerException("PrivacyUrl");
        URL Url = null;
        try {
            Url = new URL(privacyUrl);
        } catch (Exception e) {

        }
        consentForm = new ConsentForm.Builder(context, Url)
                .withListener(new ConsentFormListener() {
                    @Override
                    public void onConsentFormLoaded() {
                        showForm();

                        Toast.makeText(context,"تم تحميل نموذج الموافقة بنجاح.",Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void onConsentFormOpened() {
                        Toast.makeText(context,"تم عرض نموذج الموافقة.",Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void onConsentFormClosed(
                            ConsentStatus consentStatus, Boolean userPrefersAdFree) {

                        consentInformation.setConsentStatus(consentStatus);
                        Toast.makeText(context,"تم إغلاق نموذج الموافقة.",Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void onConsentFormError(String errorDescription) {
                        Toast.makeText(context,"موافقة شكل الخطأ."+errorDescription,Toast.LENGTH_LONG).show();
                    }
                })
                .withPersonalizedAdsOption()
                .withNonPersonalizedAdsOption()
                .withAdFreeOption()
                .build();

        consentForm.load();
    }

    private void showForm() {
        consentForm.show();
    }

    public void check() {
        initGDPR();
    }

    public PrivacyGDPRa withPublisherIds(String... publisherIds) {
        this.publisherIds = publisherIds;
        if (privacyGdprStance == null)
            throw new NullPointerException("withContext");
        return privacyGdprStance;
    }

    public PrivacyGDPRa withPhoneMode(String pPhoneDevice) {
        consentInformation.setDebugGeography(DebugGeography.DEBUG_GEOGRAPHY_NOT_EEA);
        consentInformation.addTestDevice(pPhoneDevice);
        if (privacyGdprStance == null)
            throw new NullPointerException("withContext");
        return privacyGdprStance;
    }

    public PrivacyGDPRa withTestMode(String testDevice) {
        consentInformation.setDebugGeography(DebugGeography.DEBUG_GEOGRAPHY_EEA);
        consentInformation.addTestDevice(testDevice);
        if (privacyGdprStance == null)
            throw new NullPointerException("withContext");
        return privacyGdprStance;
    }

    public PrivacyGDPRa withTestMode() {
        consentInformation.setDebugGeography(DebugGeography.DEBUG_GEOGRAPHY_EEA);
        if (privacyGdprStance == null)
            throw new NullPointerException("withContext");
        return privacyGdprStance;
    }
}
