package com.suppor.kidssongs;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.github.clans.fab.FloatingActionButton;
import com.github.clans.fab.FloatingActionMenu;
import com.google.ads.consent.ConsentForm;
import com.google.ads.consent.ConsentFormListener;
import com.google.ads.consent.ConsentInfoUpdateListener;
import com.google.ads.consent.ConsentInformation;
import com.google.ads.consent.ConsentStatus;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;


import org.w3c.dom.NodeList;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;



public class sitURL extends Fragment  implements OnItemClickListener {
    private ListView mListView;
    private TextView textView;
     public static List<stringg> feedList;
    private static String Rli;
    private item adapter;
    public static final String ACTION = "feed_list";
    private InterstitialAd mInterstitialAd;
    FloatingActionMenu fabmenu;
    FloatingActionButton fabemail, fabsher, fabapp;
    ConsentForm form;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.initialiseVariables();
        LoadRssFeedThread thread = new LoadRssFeedThread(getActivity());
        thread.execute(Rli);

        mInterstitialAd = new InterstitialAd(getActivity());
        mInterstitialAd.setAdUnitId(getString(R.string.admob1));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {

                mInterstitialAd.loadAd(new AdRequest.Builder().build());
            }

        });





    }


    @Override
    public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {

        Intent i = new Intent(getActivity(), mediaaudio.class);
        i.setAction(ACTION);
        i.putExtra("position", arg2);
        startActivity(i);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View vieww = inflater.inflate(R.layout.activity_main5, container, false);
        View view = inflater.inflate(R.layout.activity_main3, container, false);
        mListView = (ListView) view.findViewById(R.id.ListView);
        textView = (TextView) view.findViewById(R.id.text_title_list);

        fabmenu = (FloatingActionMenu) view.findViewById(R.id.fabmenu);
        fabemail = (FloatingActionButton) view.findViewById(R.id.fabemail);
        fabsher = (FloatingActionButton) view.findViewById(R.id.fabsher);
        fabapp = (FloatingActionButton) view.findViewById(R.id.fabapp);


        ConsentInformation consentInformation = ConsentInformation.getInstance(getActivity());
        String[] publisherIds = {"pub-9702813697104295"};
        consentInformation.requestConsentInfoUpdate(publisherIds, new ConsentInfoUpdateListener() {
            @Override
            public void onConsentInfoUpdated(ConsentStatus consentStatus) {

            }

            @Override
            public void onFailedToUpdateConsentInfo(String errorDescription) {

            }
        });

        URL privacyUrl = null;
        try {

            privacyUrl = new URL("https://sites.google.com/view/privacy-policy202/privacy-policy");
        } catch (MalformedURLException e) {
            e.printStackTrace();

        }
          form = new ConsentForm.Builder(getActivity(), privacyUrl)
                .withListener(new ConsentFormListener() {
                    @Override
                    public void onConsentFormLoaded() {

                        form.show();
                    }

                    @Override
                    public void onConsentFormOpened() {

                    }

                    @Override
                    public void onConsentFormClosed(
                            ConsentStatus consentStatus, Boolean userPrefersAdFree) {

                    }

                    @Override
                    public void onConsentFormError(String errorDescription) {



                    }
                })
                .withPersonalizedAdsOption()
                .withNonPersonalizedAdsOption()
                .withAdFreeOption()
                .build();

        form.load();

        fabemail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Intent.ACTION_SEND);
                String emailmessage = getString(R.string.emailmessage);
                i.setType("message/rfc822");
                i.putExtra(Intent.EXTRA_EMAIL  ,new String[]{getString(R.string.email)});
                i.putExtra(Intent.EXTRA_SUBJECT, emailmessage);

                try {
                    startActivity(Intent.createChooser(i, "Send mail..."));
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(getContext(), "There are no email clients installed.", Toast.LENGTH_SHORT).show();
                }

            }
        });
        fabsher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String appPackageName = getContext().getPackageName();
                Intent sendIntent = new Intent();
                String Hey = getString(R.string.Hey);
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT,
                        Hey +" "+"https://play.google.com/store/apps/details?id="+appPackageName );
                sendIntent.setType("text/plain");
                startActivity(sendIntent);
            }
        });
        fabapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String appPackageName = getContext().getPackageName();
                String url = "https://play.google.com/store/apps/details?id="+appPackageName;
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });
        if (feedList != null) {
            updateUi();
        }
        return view;
    }

    public class LoadRssFeedThread extends AsyncTask<String, stringg, Void> {

        private ProgressDialog dialog;

        public LoadRssFeedThread(Activity activity) {
            super.onPreExecute();
             dialog = new ProgressDialog(activity );
            dialog.setMessage("Loading...");
            dialog.show();

        }

        @Override
        protected Void doInBackground(String... params) {
            MainActivity7 parser = new MainActivity7();
            NodeList nodelist = parser.getRSSFeedItems(params[0]);
            if (nodelist != null) {
                int length = nodelist.getLength();
                for (int i = 0; i < length; i++) {
                    stringg detail = parser.getResult(nodelist, i);
                    if (detail != null) {
                        sitURL.feedList.add(detail);
                        publishProgress(detail);
                    }
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            // TODO Auto-generated method stub
            updateUi();
            if (dialog.isShowing())
                dialog.dismiss();
            super.onPostExecute(result);
        }


    }

    private void updateUi() {
        adapter = new item(getActivity(), feedList);
        mListView.setAdapter(adapter);
        mListView.setOnItemClickListener(sitURL.this);
    }

    public void initialiseVariables() {



        feedList = new ArrayList<stringg>();
        Context context = getActivity().getApplicationContext();
        Rli = "https://raw.githubusercontent.com/atifff/jadiad/master/"+ context.getPackageName();


    }


}
