package com.suppor.kidssongs;


import android.app.Activity;
import android.util.DisplayMetrics;

public class MainActivity8 {
	private static MainActivity8 utils;

	public MainActivity8() {}

	public int progressToTimer(int progress, int dosi) {
		int currentDuration = 0;
		dosi = (int) (dosi / 1000);
		currentDuration = (int) ((((double)progress) / 100) * dosi);

		return currentDuration * 1000;
	}
	public int getNoOfColumns(Activity c){
		DisplayMetrics metrics = new DisplayMetrics();
		c.getWindowManager().getDefaultDisplay().getMetrics(metrics);
		return 1;
	}

	public int getProgressPercentage(long currentDuration, long dosi){
		Double percentage = (double) 0;
		
		long currentSeconds = (int) (currentDuration / 1000);
		long totalSeconds = (int) (dosi / 1000);
		
		percentage =(((double)currentSeconds)/totalSeconds)*100;
		
		return percentage.intValue();
	}

	public static MainActivity8 getInstance(){
		if(utils==null){
			utils=new MainActivity8();
		}
		return utils;
	}
	public String milliSecondsToTimer(long milliseconds){
		String finalTimerString = "";
		String secondsString = "";

		int hours = (int)( milliseconds / (1000*60*60));
		int minutes = (int)(milliseconds % (1000*60*60)) / (1000*60);
		int seconds = (int) ((milliseconds % (1000*60*60)) % (1000*60) / 1000);
		if(hours > 0){
			finalTimerString = hours + ":";
		}

		if(seconds < 10){
			secondsString = "0" + seconds;
		}else{
			secondsString = "" + seconds;}

		finalTimerString = finalTimerString + minutes + ":" + secondsString;

		return finalTimerString;
	}

}
