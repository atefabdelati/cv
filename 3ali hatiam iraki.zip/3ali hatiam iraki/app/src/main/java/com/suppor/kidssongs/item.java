package com.suppor.kidssongs;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;


public class item extends BaseAdapter {


    private AdView mAdView;

    LayoutInflater inflater;
    private List<stringg> Datalist = null;
    private ArrayList<stringg> arraylist;
    Context context;


    public item(Activity context, List<stringg> openSite) {
        this.context = context;
        this.Datalist = openSite;
        inflater = LayoutInflater.from(context);
        this.arraylist = new ArrayList<>();
        this.arraylist.addAll(openSite);


    }

    @Override
    public int getCount() {
        return Datalist.size();
    }

    @Override
    public Object getItem(int position) {
        return Datalist.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        int contadorAnuncio = position;
        if (contadorAnuncio > 0 && contadorAnuncio % 9 == 0) {

            View view1 = inflater.inflate(R.layout.activity_main, null);
            Log.i("Inicio en 10", "inicio anuncio");

            mAdView = view1.findViewById(R.id.adView);
            AdRequest adRequest = new AdRequest.Builder().build();
            mAdView.loadAd(adRequest);

            return view1;

        } else {

            View Item = inflater.inflate(R.layout.activity_main5, null);
            TextView txtTitle = (TextView) Item.findViewById(R.id.titleid);
            CircleImageView imageView = (CircleImageView) Item.findViewById(R.id.imagview);
            txtTitle.setText(Datalist.get(position).getTitle());
            Glide.with(context).load(Datalist.get(position).getImg()).into(imageView);

            return Item;
        }
    }
}





