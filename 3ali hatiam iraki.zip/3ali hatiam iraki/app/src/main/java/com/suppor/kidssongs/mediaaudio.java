package com.suppor.kidssongs;

import android.graphics.drawable.AnimationDrawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

import java.io.IOException;
import java.util.Timer;

import de.hdodenhof.circleimageview.CircleImageView;


public class mediaaudio extends AppCompatActivity implements SeekBar.OnSeekBarChangeListener, OnCompletionListener, MediaPlayer.OnErrorListener {

    private SeekBar seek_bar;
    private ImageButton button_Play, button_Next, button_Previous;

    private CircleImageView imageImageView;
    private TextView current_time, sound_duration, arnwan;
    private MediaPlayer media_voice;
    private AnimationDrawable mAnimation;
    private Handler mHandler = new Handler();
    private MainActivity8 utils;

    private int currentSongIndex = 0;
    private int SELECTED_POSITION = -1;
    int tiemman = 0;
    private static final int WAITIMER = 5000;
    private Timer waitttemerr;
    private InterstitialAd mInterstitialAd;
    private AdView mAdView;
    String ketDev = "8F2C46091ECD68C0A766BAE9C20FFFB5";

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(getString(R.string.admob1));
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                mInterstitialAd.loadAd(new AdRequest.Builder().build());
            }

        });


        new CountDownTimer(7000, 3000) {
            @Override
            public void onTick(long m) {
            }

            @Override
            public void onFinish() {
                if (mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();

                }
            }
        }.start();



        SELECTED_POSITION = getIntent().getIntExtra("position", -1);

        processing_actionBar();
        linking_elements();


        media_voice = new MediaPlayer();
        utils = new MainActivity8();

        media_voice.setOnCompletionListener(this);
        media_voice.setOnErrorListener(this);
        seek_bar.setOnSeekBarChangeListener(this);
        seek_bar.setMax(media_voice.getDuration());


        currentSongIndex = SELECTED_POSITION;
        if (SELECTED_POSITION != -1) {
            playSong(SELECTED_POSITION);
        } else {
            Toast.makeText(getBaseContext(), getString(R.string.error), Toast.LENGTH_SHORT).show();
        }


        button_Play.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {


                if (media_voice.isPlaying()) {

                    tiemman++;
                    if (tiemman >= 4) {
                        tiemman = 1;
                        if (mInterstitialAd.isLoaded()) {
                            mInterstitialAd.show();

                        }
                    }

                    if (media_voice != null) {
                        media_voice.pause();


                        button_Play.setImageResource(R.drawable.ic_play_circle_outline_black_24dp);

                    }
                } else {

                    tiemman++;
                    if (tiemman >= 4) {
                        tiemman = 1;
                        if (mInterstitialAd.isLoaded()) {
                            mInterstitialAd.show();

                        }
                    }


                    if (media_voice != null) {
                        media_voice.start();
                        button_Play.setImageResource(R.drawable.ic_pause_circle_outline_black_24dp);
                    }
                }
            }



        });

        button_Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tiemman++;
                if (tiemman >= 4) {
                    tiemman = 1;
                    if (mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();

                    }
                }

                playNext();
            }
        });
        button_Previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tiemman++;
                if (tiemman >= 3) {
                    tiemman = 1;
                    if (mInterstitialAd.isLoaded()) {
                        mInterstitialAd.show();

                    }
                }

                playPrevious();
            }
        });
        PhoneStateListener phoneStateListener = new PhoneStateListener() {
            @Override
            public void onCallStateChanged(int state, String incomingNumber) {
                if (state == TelephonyManager.CALL_STATE_RINGING) {
                } else if (state == TelephonyManager.CALL_STATE_IDLE) {
                } else if (state == TelephonyManager.CALL_STATE_OFFHOOK) {
                }
                super.onCallStateChanged(state, incomingNumber);
            }
        };
        TelephonyManager mgr = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        if (mgr != null) {
            mgr.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);
        }
    }


    public void processing_actionBar() {
        arnwan = (TextView) findViewById(R.id.arnwan);
        arnwan.setText(sitURL.feedList.get(SELECTED_POSITION).getTitle());
        imageImageView = (CircleImageView) findViewById(R.id.img_equilizer);
        Glide.with(this).load(sitURL.feedList.get(SELECTED_POSITION).getImg()).into(imageImageView);


    }

    public void linking_elements() {
        seek_bar = (SeekBar) findViewById(R.id.seekbar);
        current_time = (TextView) findViewById(R.id.songCurrentDurationLabel1);
        sound_duration = (TextView) findViewById(R.id.songTotalDurationLabel);
        button_Play = (ImageButton) findViewById(R.id.btnPlay);

        button_Next = (ImageButton) findViewById(R.id.btnNext);
        button_Previous = (ImageButton) findViewById(R.id.btnPrevious);

    }


    public void playPrevious() {
        mHandler.removeCallbacks(mUpdateTimeTask);
        seek_bar.setProgress(0);
        if (currentSongIndex > 0) {
            currentSongIndex--;
            playSong(currentSongIndex);
        }
    }

    public void playNext() {
        if (currentSongIndex < sitURL.feedList.size() - 1) {
            mHandler.removeCallbacks(mUpdateTimeTask);
            seek_bar.setProgress(0);
            currentSongIndex++;
            playSong(currentSongIndex);
        }
    }

    public void playSong(int songIndex) {
        try {
            media_voice.reset();
            media_voice.setAudioStreamType(AudioManager.STREAM_MUSIC);
            media_voice.setDataSource(sitURL.feedList.get(songIndex).getUrl());

            media_voice.prepareAsync();
            media_voice.setOnPreparedListener(new OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    mp.start();
                    updateProgressBar();
                    button_Play.setImageResource(R.drawable.ic_pause_circle_outline_black_24dp);
                }
            });

            media_voice.setOnCompletionListener(new OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    tiemman++;
                    if (tiemman >= 3) {
                        tiemman = 1;
                         current_time.setText("");
                        playNext();

                    }else{
                     //  button_Play.setImageResource(R.drawable.image_return);
                         current_time.setText("");
                    }
                }
            });



            button_Play.setImageResource(R.drawable.ic_pause_circle_outline_black_24dp);
            arnwan.setText(sitURL.feedList.get(songIndex).getTitle());
            seek_bar.setProgress(0);
            seek_bar.setMax(100);

        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        Toast.makeText(getBaseContext(), getString(R.string.problem_url), Toast.LENGTH_LONG).show();
        finish();
        return false;
    }


    public void updateProgressBar() {
        mHandler.postDelayed(mUpdateTimeTask, 100);
    }

    private Runnable mUpdateTimeTask = new Runnable() {
        public void run() {
            long totalDuration = media_voice.getDuration();
            long currentDuration = media_voice.getCurrentPosition();

            sound_duration.setText("" + utils.milliSecondsToTimer(totalDuration));
            current_time.setText("" + utils.milliSecondsToTimer(currentDuration));

            int progress = (int) (utils.getProgressPercentage(currentDuration, totalDuration));
            seek_bar.setProgress(progress);

            mHandler.postDelayed(this, 100);
        }
    };


    @Override
    public void onDestroy() {
        super.onDestroy();
        media_voice.release();
    }


    @Override
    public void onBackPressed() {
        tiemman++;
        if (tiemman >= 1) {
            tiemman = 0;
            if (mInterstitialAd.isLoaded()) {
                mInterstitialAd.show();

            }
        }
        mHandler.removeCallbacks(mUpdateTimeTask);
        seek_bar.setProgress(0);
        finish();
        super.onBackPressed();
    }

    @Override
    public void onCompletion(MediaPlayer arg0) {


        if (currentSongIndex < (sitURL.feedList.size() - 1)) {
            playSong(currentSongIndex + 1);
            currentSongIndex = currentSongIndex + 1;
        } else {

            playSong(0);
            currentSongIndex = 0;
        }

    }



    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromTouch) {

    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {
        mHandler.removeCallbacks(mUpdateTimeTask);
    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        mHandler.removeCallbacks(mUpdateTimeTask);
        int totalDuration = media_voice.getDuration();
        int currentPosition = utils.progressToTimer(seekBar.getProgress(), totalDuration);

        media_voice.seekTo(currentPosition);

        updateProgressBar();
    }


}

