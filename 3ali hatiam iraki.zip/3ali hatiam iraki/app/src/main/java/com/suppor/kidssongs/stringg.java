package com.suppor.kidssongs;

import android.os.Parcel;
import android.os.Parcelable;


public class stringg implements Parcelable {

    public static final int CREATOR = 1;

    String url;
    String title;
    String titlee;
    String img;


    public String getTitlee(String ttttt) {
        return titlee;
    }

    public void setTitlee(String titlee) {
        this.titlee = titlee;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {

    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getTitle() {
        return title;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}