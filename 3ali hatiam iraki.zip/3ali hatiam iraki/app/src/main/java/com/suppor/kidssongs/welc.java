package com.suppor.kidssongs;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.RelativeLayout;
import android.widget.TextView;


import com.google.android.gms.ads.AdRequest;
import com.onesignal.OneSignal;

import java.util.Timer;
import java.util.TimerTask;


public class welc extends Activity {
    private static final int WAIT_TIME = 3000;
    private Timer waitTimer;
    private void startMainActivity() {
        startActivity(new Intent(this, mmTabHost.class));
        finish();
    }

    Animation sonlode;
    Animation desonlo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);





        OneSignal.startInit(this)
                .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)
                .init();
        RelativeLayout mRelativeLayout = (RelativeLayout)findViewById(R.id.mRelativeLayout);
        TextView textView2 = (TextView)findViewById(R.id.textView2);
        sonlode = AnimationUtils.loadAnimation(this,R.anim.sonlode);
        mRelativeLayout.setAnimation(sonlode);
        textView2.setAnimation(sonlode);
        waitTimer = new Timer();
        waitTimer.schedule(new TimerTask() {
            @Override
            public void run() {welc.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        startMainActivity();
                    }
                });
            }
        }, WAIT_TIME);
    }

}