package com.suppor.kidssongs;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTabHost;
import android.support.v7.app.ActionBar;
import android.view.View;
import android.widget.TabHost;
import android.widget.TabWidget;
import android.widget.TextView;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.github.javiersantos.materialstyleddialogs.MaterialStyledDialog;
import com.google.ads.consent.ConsentInformation;
import com.ixidev.gdpr.GDPRChecker;
import com.mikepenz.iconics.IconicsDrawable;
import com.mikepenz.material_design_iconic_typeface_library.MaterialDesignIconic;


public class mmTabHost extends FragmentActivity implements TabHost.OnTabChangeListener{
    private FragmentTabHost mTabHost;
    private static final String MARIPMN = "systmnoa";

    private Context context;



    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main1);




        mTabHost = (FragmentTabHost) findViewById(android.R.id.tabhost);
        mTabHost.setup(this, getSupportFragmentManager(), R.id.mmTabHost);
        mTabHost.addTab(mTabHost.newTabSpec(MARIPMN).setIndicator("off"), sitURL.class, null);
        mTabHost.setOnTabChangedListener(this);
        context = this;

        TabWidget widget = mTabHost.getTabWidget();
        for (int i = 0; i < widget.getChildCount(); i++) {
            View v = widget.getChildAt(i);
            TextView tv = (TextView) v.findViewById(android.R.id.title);
            if (tv == null) {
                continue;
            }
        }
    }
    @SuppressLint("WrongConstant")
    @Override
    public void onTabChanged(String tabId) {
        getActionBar().setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);
    }


    @Override
    public void onBackPressed() {
        final MaterialStyledDialog.Builder mMaterialStyledDialog = new MaterialStyledDialog.Builder(context)
                .setIcon(new IconicsDrawable(context).icon(MaterialDesignIconic.Icon.gmi_close_circle_o).color(Color.WHITE))
                .withDialogAnimation(true)
                .setTitle(getString(R.string.app_name))
                .setDescription(getString(R.string.messag))
                .setHeaderColor(R.color.dv)
                .setPositiveText(getString(R.string.yes))
                .onPositive(new MaterialDialog.SingleButtonCallback() {
                    @Override
                    public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                        finish();
                    }
                })
                .setNegativeText(getString(R.string.no));
        mMaterialStyledDialog.show();

    }


    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
